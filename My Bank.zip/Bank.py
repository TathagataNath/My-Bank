from GUIHelper import GUI
from DBHelper import DBHelper
from datetime import date

class Bank():

    def __init__(self):
        self._user = None
        self._currentAmount=None
        self._dbobject = DBHelper()
        self._guiobject=GUI(self)
        self._guiobject.firstPage()

    def verifyDetails(self, items, kind='', transaction='', flag=7):

        if kind in ['Login Page','transfer']:

            if items[0].get() == '':
                self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR ACCOUNT NUMBER")
                return False
            elif not items[0].get().isnumeric():
                self._guiobject.displayError("    INPUT ERROR","INVALID ACCOUNT NUMBER")
                return False
            if kind=='transfer' :
                if int(items[0].get())==self._user[0] :
                    self._guiobject.displayError("    INPUT ERROR","CAN NOT TRANSFER TO OWN ACCOUNT")
                    return False

        if kind != 'transfer' :

            if kind in ['New Account','update'] :

                if items[0].get() == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR NAME")
                    return False

            if kind != 'Ask For Amount':

                if items[1].get() == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR PASSWORD")
                    return False

            if kind in ['New Account','update'] :

                if items[2].get() == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR EMAIL")
                    return False
                elif '@' not in items[2].get() or '@' in items[2].get()[(items[2].get().index('@')) + 1:] or len(items[2].get().split()) > 1 :
                    self._guiobject.displayError("    INPUT ERROR","INVALID EMAIL")
                    return False

                if items[3].get() == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR MOBILE NUMBER")
                    return False
                elif not items[3].get().isnumeric() or len(items[3].get()) != 10:
                    self._guiobject.displayError("    INPUT ERROR","INVALID MOBILE NUMBER")
                    return False

                if items[4].get() == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR ADHAAR NUMBER")
                    return False
                elif not items[4].get().isnumeric() or len(items[4].get()) != 12:
                    self._guiobject.displayError("    INPUT ERROR","INVALID ADHAAR NUMBER")
                    return False

                if items[5].get() == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR PAN NUMBER")
                    return False
                elif items[5].get().isnumeric() or items[5].get().isalpha():
                    self._guiobject.displayError("    INPUT ERROR","INVALID PAN NUMBER")
                    return False

                if kind !='update' and items[6] == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE PROVIDE YOUR PHOTOGRAPH")
                    return False

            if kind in ['New Account', 'Ask For Amount']:

                if items[flag].get() == '':
                    self._guiobject.displayError("    INPUT ERROR","PLEASE ENTER YOUR AMOUNT")
                    return False
                else:
                    try:
                        self._amount = float(items[flag].get())
                        if self._amount <= 0:
                            self._guiobject.displayError("    INPUT ERROR","AMOUNT HAS TO BE GREATER THAN 0")
                            return False
                        if self._amount < 100 :
                            self._guiobject.displayError("    INPUT ERROR","MINIMUM {} IS Rs. 100.0".format(transaction.upper()))
                            return False
                        if transaction in['withdraw','transfer'] :
                            if (self._currentAmount - self._amount) < 500 :
                                self._guiobject.displayError("    INSUFFICIENT BALANCE","INSUFFICIENT BALANCE FOR THIS {}\nCURRENT BALANCE : Rs. {}\nMINIMUM BALANCE : Rs. 500.0".format(transaction.upper(), self._currentAmount))
                                return False
                    except ValueError:
                        self._guiobject.displayError("    INPUT ERROR","INVALID AMOUNT")
                        return False
        return True

    def recordTransaction(self,acc_num='',type='',amount=0.0,balance=0.0):

        transactionDict = {
            'account_number': acc_num,
            'date': str(date.today()),
            'transaction_type': type,
            'amount': amount,
            'balance': balance
        }

        flag = self._dbobject.insert('transaction', transactionDict)

        return flag

    def newAccountHandler(self, items):

        if self.verifyDetails(items, kind="New Account"):

            customerDict = {
                'name': items[0].get(),
                'password': items[1].get(),
                'email': items[2].get(),
                'mobile_number': items[3].get(),
                'adhaar_number': items[4].get(),
                'pan_number': items[5].get(),
                'photo': items[6],
                'balance': float(items[7].get()),
                'status':'active'
            }

            flag = self._dbobject.insert('customer', customerDict)

            if flag:

                account_number = self._dbobject.search(get_account_number=True)[0][0]

                trans_flag=self.recordTransaction(acc_num=account_number, type='initial deposit', amount=float(items[7].get()), balance=float(items[7].get()))

                if trans_flag :
                    self._guiobject.displayInfo("    CREATE ACCOUNT","ACCOUNT CREATED\nACCOUNT NUMBER : {}\nPLEASE LOGIN TO CONTINUE".format(account_number))
                    self._guiobject.firstPage()

            else:
                self._guiobject.displayInfo("    CREATE ACCOUNT", "ACCOUNT NOT CREATED")

    def loginHandler(self, items):

        if self.verifyDetails(items, kind="Login Page"):

            response = self._dbobject.search('customer', 'account_number', items[0].get(), 'password', items[1].get(), 'status', 'active')

            if (response == []):
                self._guiobject.displayError("    INPUT ERROR","ACCOUNT NOT FOUND")
            else:
                self._user = response[0]
                self._currentAmount=self._user[-2]
                self._guiobject.afterLogin()

    def logOutHandler(self):

        flag = self._guiobject.displayYesNo("    LOGOUT", "DO YOU REALLY WANT TO LOGOUT ?")

        if flag:
            self._guiobject.closeWindow(logout=True)
            self._guiobject.login()

    def quitHandler(self):

        flag = self._guiobject.displayYesNo("    QUIT", "DO YOU REALLY WANT TO QUIT ?")

        if flag:
            self._guiobject.closeWindow()

    def quitHandlerOnlyRoot1(self):

        flag = self._guiobject.displayYesNo("    QUIT", "DO YOU REALLY WANT TO QUIT ?")

        if flag:
            self._guiobject.closeWindow(root='root1')


    def transactionHandler(self, amount_entry, kind):

        if self.verifyDetails(amount_entry, kind='Ask For Amount', transaction=kind.split()[0], flag=0):

            if kind=='deposit by self' :
                self._currentAmount+=self._amount
            else :
                self._currentAmount-=self._amount

            flag=self._dbobject.update({'balance':str(self._currentAmount)}, self._user[0])

            if flag :

                trans_flag=self.recordTransaction(acc_num=self._user[0], type= kind, amount=float(amount_entry[0].get()), balance=self._currentAmount)

                if trans_flag :

                    self._guiobject.displayInfo("{0}".format(kind.split()[0].upper()),"{0} SUCCESSFUL\nCURRENT BALANCE : Rs. {1}".format(kind.split()[0].upper(),str(self._currentAmount)))
                    self._guiobject.afterLogin()

            else :
                self._guiobject.displayInfo("{}".format(kind.split()[0].upper()),"{0} UNSUCCESSFUL".format((kind.split(0)[0].upper())))

    def showCurrentBalance(self):

        self._guiobject.displayInfo("    CURRENT BALANCE","YOUR CURRENT BALANCE IS : Rs. "+str(self._currentAmount))

    def closeAccountHandler(self):

        flag=self._guiobject.displayYesNo("    CLOSE ACCOUNT","DO YOU REALLY WANT TO CLOSE YOUR ACCOUNT ?")

        if flag :

            close_flag=self._dbobject.update({'status':'closed'}, self._user[0])

            if close_flag :
                self._guiobject.closeWindow(root='root1')
                self._guiobject.displayInfo("    CLOSE ACCOUNT","ACCOUNT CLOSED")
                self._guiobject.firstPage()

    def transactionHistoryHandler(self,refresh=False):

        if refresh :
            self._guiobject.closeWindow(root='root1')

        response=self._dbobject.search('transaction','account_number',self._user[0])

        transaction_text="DATE\t\tTYPE\t\tAMOUNT\tBALANCE\n\n"

        for i in response :
            for j in i[2:] :
                if j==i[2:][0] :
                    j='/'.join(str(j).split('-')[::-1])
                transaction_text+=j+"\t"
                if j==i[-2] :
                    transaction_text+="\t"
            transaction_text+="\n"

        self._guiobject.transactionHistory(transaction_text)

    def transactionPossibility(self,kind):

        if self._currentAmount <= 500 :
            self._guiobject.displayError("    INSUFFICIENT BALANCE","{} NOT POSSIBLE\nCURRENT BALANCE : Rs. {}\nMINIMUM BALANCE : Rs. 500.0".format(kind,self._currentAmount))
        else :
            if kind=='WITHDRAW' :
                self._guiobject.askForAmount(kind)
            else :
                self._guiobject.moneyTransfer()

    def transferPossibility(self,account_entry):

        if self.verifyDetails(account_entry, kind='transfer') :

            response=self._dbobject.search('customer','account_number',account_entry[0].get(), 'status', 'active')

            if response == [] :
                self._guiobject.displayError("    INPUT ERROR","ACCOUNT NOT FOUND")
            else :
                self._receiver=response[0]
                self._guiobject.askForAmount(kind='TRANSFER')

    def moneyTransferHandler(self,amount_entry):

        if self.verifyDetails(amount_entry, kind='Ask For Amount', transaction='transfer', flag=0):

            receiver_current_amount=self._receiver[-2]

            self._currentAmount-=self._amount
            receiver_current_amount+=self._amount

            flag1=self._dbobject.update({'balance':str(self._currentAmount)}, self._user[0])
            flag2=self._dbobject.update({'balance':str(receiver_current_amount)}, self._receiver[0])

            if flag1 and flag2 :

                transflag1=self.recordTransaction(acc_num=self._user[0],type="to a/c no : {}".format(self._receiver[0]), amount=self._amount, balance=self._currentAmount)
                transflag2=self.recordTransaction(acc_num=self._receiver[0],type="from a/c no : {}".format(self._user[0]), amount=self._amount, balance=receiver_current_amount)

                if transflag1 and transflag2 :
                    self._guiobject.displayInfo("    TRANSFER","TRANSFER SUCCESSFUL\nCURRENT BALANCE : {}".format((self._currentAmount)))
                    self._guiobject.afterLogin()

            else :
                self._guiobject.displayInfo("    TRANSFER","TRANSFER UNSUCCESSFUL")

    def viewProfileHandler(self) :

       self._guiobject.updateProfile(self._user)

    def updateProfileHandler(self,items):

        if self.verifyDetails(items,kind='update') :

            updateDict={
                'name':items[0].get(),
                'password':items[1].get(),
                'email':items[2].get(),
                'mobile_number':items[3].get(),
                'adhaar_number':items[4].get(),
                'pan_number':items[5].get(),
                'photo':items[6]
            }

            flag=self._dbobject.update(updateDict,self._user[0])

            if flag :
                self._guiobject.displayInfo("    UPDATE PROFILE","PROFILE UPDATED")
                response=self._dbobject.search('customer','account_number',self._user[0])
                self._user=response[0]
                self._guiobject.afterLogin()
            else :
                self._guiobject.displayInfo("    UPDATE PROFILE","PROFILE NOT UPDATED")

x = Bank()
