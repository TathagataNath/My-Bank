import mysql.connector

class DBHelper :

    def __init__(self):

        try:
            self._connection = mysql.connector.connect(host="127.0.0.1", user="root", password="", database="bank")
            self._myCursor = self._connection.cursor()
        except:
            print("SERVER ERROR")

    def insert(self, table, inputDict):
        cols = ""
        vals = ""

        for i in inputDict:
            cols += "`" + i + "`" + ","
            vals += "'" + str(inputDict[i]) + "'" + ","

        cols = cols[:-1]
        vals = vals[:-1]

        try:
            self._myCursor.execute("INSERT INTO `{}` ({}) VALUES ({})".format(table, cols, vals))
            self._connection.commit()
            return True
        except:
            return False

    def getAccountNumber(self):

        self._myCursor.execute("SELECT count(`account_number`) FROM `customer`")
        response=self._myCursor.fetchall()
        return response

    def search(self,table,column1,value1,column2='',value2='',column3='',value3=''):

        if table=='customer' and column2!='' :
            self._myCursor.execute("SELECT * FROM `{}` WHERE `{}`= {} AND `{}` = '{}' AND `{}` = '{}'".format(table,column1,value1,column2,value2,column3,value3))
        else :
            self._myCursor.execute("SELECT * FROM `{}` WHERE `{}` = {}".format(table,column1,value1))

        response=self._myCursor.fetchall()
        return response

    def update(self,table,target_column,target_value,column1,value1,column2='',value2=''):

        try :
            if column2 != '' :
                self._myCursor.execute("UPDATE `{}` SET `{}` = {} WHERE `{}` = '{}' AND `{}` = '{}'".format(table,target_column,target_value,column1,value1,column2,value2))
            else :
                self._myCursor.execute("UPDATE `{}` SET `{}` = {} WHERE `{}` = '{}'".format(table,target_column,target_value,column1,value1))

            self._connection.commit()
            return True
        except :
            return False

    def updateProfile(self, updateDict, account_number):

        update_string=""
        for i in updateDict :
            update_string+="`" + i +"`" + "=" + "'" + updateDict[i] + "'"+ ","

        update_string=update_string[:-1]

        try :
            self._myCursor.execute("UPDATE `customer` SET "+update_string+" WHERE `account_number` = '{}'".format(account_number))
            self._connection.commit()
            return True
        except :
            return False

    def closeAccount(self,account_number):

        try :
            self._myCursor.execute("UPDATE `customer` SET `status`='closed' WHERE `account_number`= '{}'".format(account_number))
            self._connection.commit()
            return True
        except:
            return False