from tkinter import *
from tkinter import messagebox
from tkinter import filedialog

from PIL import ImageTk, Image


class GUI:

    def __init__(self, other):

        self._path = ''
        self._other = other
        self._root=self.createRoot()
        self._root1=None

    def createRoot(self,secondRoot=False):

        if secondRoot :
            root=Toplevel()
            root.protocol("WM_DELETE_WINDOW", self._other.quitHandlerOnlyRoot1)

        else :
            root=Tk()
            root.protocol("WM_DELETE_WINDOW", self._other.quitHandler)

        image=PhotoImage(file="icon.png")
        root.iconphoto(False,image)
        root.resizable(False,False)
        root.configure(background="#bdb76b")

        return root

    def setUpFrame(self,root):

        self.frame1 = Frame(root, bg="#bdb76b")
        self.frame1.grid(row=0, column=0)

        self.frame2 = Frame(root, bg="#bdb76b")
        self.frame2.grid(row=0,column=20)

        self.frame3= Frame(root, bg="#bdb76b")
        self.frame3.grid(row=10,column=0)

    def viewUI(self,kind='',receiver=''):

        if kind=='First Page' :

            create_account=Button(self.frame1,text="Create Account",bg="#008000",fg="#fff",cursor="hand2",width=12, height=2,command= lambda : self.createAccount())
            create_account.configure(font=("Times New Roman", 25, "bold"))
            create_account.grid(row=10, column=5, padx=(20,), ipadx=3, columnspan=2, pady=(20, 20))

            login = Button(self.frame1, text="Login To\nYour Account", bg="#008000", fg="#fff",cursor="hand2",width=12, height=2, command=lambda : self.login())
            login.configure(font=("Times New Roman", 25, "bold"))
            login.grid(row=12, column=5, padx=(20,), ipadx=3, columnspan=2, pady=(20, 0))

        if kind in ['Login Page','Ask Account Number','transfer'] :

            acc_num_label=Label(self.frame1,text=receiver+"ACCOUNT NUMBER", bg="#bdb76b", fg="#000")
            acc_num_label.configure(font=("Times New Roman",20,"bold"))
            acc_num_label.grid(row=0, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

            if kind=='view profile' :

                acc_num_view_label = Label(self.frame1, text=items[0].get(), bg="#bdb76b", fg="#000")
                acc_num_view_label.configure(font=("Times New Roman", 20, "bold"))
                acc_num_view_label.grid(row=0, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

            else :

                acc_num_entry = Entry(self.frame1)
                acc_num_entry.configure(font=("Times New Roman", 14))
                acc_num_entry.grid(row=0, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))


            if kind=='Login Page' :

                back_button = Button(self.frame3, text="BACK", bg="#008000", fg="#fff", cursor="hand2",command=lambda: self.firstPage())
                back_button.configure(font=("Times New Roman", 15, "bold"))
                back_button.grid(row=5, column=0, ipadx=3, pady=(20, 0))


        if kind in ['Login Page','New Account'] :

            password_label = Label(self.frame1, text="PASSWORD", bg="#bdb76b", fg="#000")
            password_label.configure(font=("Times New Roman", 20, "bold"))
            password_label.grid(row=1, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 10))

            password_entry = Entry(self.frame1)
            password_entry.configure(font=("Times New Roman", 14), show="\u2022")
            password_entry.grid(row=1, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(10, 10))

        if kind=='Login Page' :

            login_button = Button(self.frame1, text="LOGIN", bg="#008000", fg="#fff", cursor="hand2", command= lambda : self._other.loginHandler([acc_num_entry,password_entry]))
            login_button.configure(font=("Times New Roman", 15, "bold"))
            login_button.grid(row=2, column=10, ipadx=3, padx=(30,0), pady=(20, 0))

        if kind=='New Account' :

            name_label = Label(self.frame1, text="NAME", bg="#bdb76b", fg="#000")
            name_label.configure(font=("Times New Roman", 20, "bold"))
            name_label.grid(row=0, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

            name_entry = Entry(self.frame1)
            name_entry.configure(font=("Times New Roman", 14))
            name_entry.grid(row=0, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))

            email_label = Label(self.frame1, text="EMAIL", bg="#bdb76b", fg="#000")
            email_label.configure(font=("Times New Roman", 20, "bold"))
            email_label.grid(row=2, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 10))

            email_entry = Entry(self.frame1)
            email_entry.configure(font=("Times New Roman", 14))
            email_entry.grid(row=2, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(10, 10))

            mobile_no_label = Label(self.frame1, text="MOBILE NUMBER", bg="#bdb76b", fg="#000")
            mobile_no_label.configure(font=("Times New Roman", 20, "bold"))
            mobile_no_label.grid(row=3, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 10))

            mobile_no_entry = Entry(self.frame1)
            mobile_no_entry.configure(font=("Times New Roman", 14))
            mobile_no_entry.grid(row=3, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(10, 10))

            aadhaar_no_label = Label(self.frame1, text="AADHAR NUMBER", bg="#bdb76b", fg="#000")
            aadhaar_no_label.configure(font=("Times New Roman", 20, "bold"))
            aadhaar_no_label.grid(row=4, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 10))

            aadhaar_no_entry = Entry(self.frame1)
            aadhaar_no_entry.configure(font=("Times New Roman", 14))
            aadhaar_no_entry.grid(row=4, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(10, 10))

            pan_no_label = Label(self.frame1, text="PAN NUMBER", bg="#bdb76b", fg="#000")
            pan_no_label.configure(font=("Times New Roman", 20, "bold"))
            pan_no_label.grid(row=5, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 10))

            pan_no_entry = Entry(self.frame1)
            pan_no_entry.configure(font=("Times New Roman", 14))
            pan_no_entry.grid(row=5, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(10, 10))

            photo_label=Label(self.frame1,text="PHOTO",bg="#bdb76b",fg="#000")
            photo_label.configure(font=("Times New Roman",20,"bold"))
            photo_label.grid(row=6, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 10))

            photo_button = Button(self.frame1, text="CHOOSE PHOTO", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self.chooseImage(self._root))
            photo_button.configure(font=("Times New Roman", 14, "bold"))
            photo_button.grid(row=6, column=20, padx=(10, 10), ipadx=3, columnspan=2, pady=(10, 10))

            amount_label = Label(self.frame1, text="AMOUNT\nMINIMUM Rs. 100", bg="#bdb76b", fg="#000",justify=LEFT)
            amount_label.configure(font=("Times New Roman", 20, "bold"))
            amount_label.grid(row=7, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 5))

            amount_entry = Entry(self.frame1)
            amount_entry.configure(font=("Times New Roman", 14))
            amount_entry.grid(row=7, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(10, 5))

            create_account_button = Button(self.frame3, text="CREATE ACCOUNT", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self._other.newAccountHandler([name_entry, password_entry, email_entry, mobile_no_entry, aadhaar_no_entry, pan_no_entry, self._path, amount_entry]))
            create_account_button.configure(font=("Times New Roman", 15, "bold"))
            create_account_button.grid(row=9, column=15, padx=(10, 10), ipadx=3, columnspan=2, pady=(30, 10))

            back_button = Button(self.frame3, text="BACK", bg="#008000", fg="#fff", cursor="hand2", command=lambda: self.firstPage())
            back_button.configure(font=("Times New Roman", 15, "bold"))
            back_button.grid(row=15, column=25, padx=(50, 10), ipadx=3, columnspan=2, pady=(30, 10))

        if kind=='transfer' :

            ok_button = Button(self.frame3, text="OK", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self._other.transferPossibility([acc_num_entry]))
            ok_button.configure(font=("Times New Roman", 15, "bold"))
            ok_button.grid(row=9, column=15, padx=(10, 10), ipadx=3, columnspan=2, pady=(20, 10))

            back_button = Button(self.frame3, text="BACK", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self.afterLogin())
            back_button.configure(font=("Times New Roman", 15, "bold"))
            back_button.grid(row=15, column=25, padx=(10, 10), ipadx=3, columnspan=2, pady=(10, 10))


    def askForAmount(self,kind) :

        self.clearGrid()
        self._root.minsize(800,270)
        self._root.title("    PROVIDE AMOUNT")
        self.setUpFrame(self._root)

        s="ENTER AMOUNT TO "+kind+"\nMINIMUM AMOUNT Rs. 100"
        if kind in ["WITHDRAW","TRANSFER"] :
            s+="\nMINIMUM BALANCE Rs. 500"

        amount_label = Label(self.frame1, text=s,bg="#bdb76b", fg="#000",justify=LEFT)
        amount_label.configure(font=("Times New Roman", 20, "bold"))
        amount_label.grid(row=0, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 5))

        amount_entry = Entry(self.frame1)
        amount_entry.configure(font=("Times New Roman", 14))
        amount_entry.grid(row=0, column=30, columnspan=5, padx=(20,0), sticky=W, ipadx=20, ipady=7, pady=(10, 5))

        if kind in ['DEPOSIT','WITHDRAW'] :
            deposit_withdraw_transfer_button = Button(self.frame3, text=kind, bg="#008000", fg="#fff", cursor="hand2", command = lambda :self._other.transactionHandler([amount_entry],kind.lower()+" by self"))
        else :
            deposit_withdraw_transfer_button = Button(self.frame3, text="TRANSFER", bg="#008000", fg="#fff", cursor="hand2", command = lambda :self._other.moneyTransferHandler([amount_entry]))

        deposit_withdraw_transfer_button.configure(font=("Times New Roman", 15, "bold"))
        deposit_withdraw_transfer_button.grid(row=2, column=15, padx=(10, 10), ipadx=3, columnspan=2, pady=(20, 10))

        if kind in ['DEPOSIT','WITHDRAW'] :
            back_button = Button(self.frame3, text="BACK", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self.afterLogin())
        else :
            back_button = Button(self.frame3, text="BACK", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self.moneyTransfer())

        back_button.configure(font=("Times New Roman", 15, "bold"))
        back_button.grid(row=8, column=25, padx=(10, 10), ipadx=3, columnspan=2, pady=(20, 10))

        self._root.mainloop()

    def afterLogin(self):

        self.clearGrid()
        self._root.minsize(635,600)
        self._root.title("    SERVICES")
        self.setUpFrame(self._root)

        deposit_button = Button(self.frame1, text="DEPOSIT", bg="#008000", fg="#fff", cursor="hand2", width=12, height=2, command = lambda : self.askForAmount("DEPOSIT"))
        deposit_button.configure(font=("Times New Roman", 25, "bold"))
        deposit_button.grid(row=10, column=3, padx=(30,), ipadx=3, columnspan=2, pady=(30, 20))

        withdraw_button = Button(self.frame1, text="WITHDRAW", bg="#008000", fg="#fff", cursor="hand2",  width=12, height=2, command = lambda :self._other.transactionPossibility(kind="WITHDRAW"))
        withdraw_button.configure(font=("Times New Roman", 25, "bold"))
        withdraw_button.grid(row=10, column=20, padx=(30,), ipadx=3, columnspan=2, pady=(30, 20))

        money_transfer_button = Button(self.frame1, text="MONEY\nTRANSFER", bg="#008000", fg="#fff", cursor="hand2",  width=12, height=2,command = lambda : self._other.transactionPossibility(kind="TRANSFER"))
        money_transfer_button.configure(font=("Times New Roman", 25, "bold"))
        money_transfer_button.grid(row=12, column=3, padx=(30,), ipadx=3, columnspan=2, pady=(20, 20))

        transaction_history_button = Button(self.frame1, text="TRANSACTION\nHISTORY", bg="#008000", fg="#fff", cursor="hand2",  width=12, height=2, command = lambda : self._other.transactionHistoryHandler())
        transaction_history_button.configure(font=("Times New Roman", 25, "bold"))
        transaction_history_button.grid(row=12, column=20, padx=(30,), ipadx=3, columnspan=2, pady=(20, 20))

        update_profile_button = Button(self.frame1, text="UPDATE\nPROFILE", bg="#008000", cursor="hand2",  fg="#fff", width=12, height=2, command = lambda : self._other.viewProfileHandler())
        update_profile_button.configure(font=("Times New Roman", 25, "bold"))
        update_profile_button.grid(row=14, column=3, padx=(30,), ipadx=3, columnspan=2, pady=(20, 20))

        current_balance_button = Button(self.frame1, text="CURRENT\nBALANCE", bg="#008000", fg="#fff", cursor="hand2",  width=12, height=2, command = lambda : self._other.showCurrentBalance())
        current_balance_button.configure(font=("Times New Roman", 25, "bold"))
        current_balance_button.grid(row=14, column=20, padx=(30,), ipadx=3, columnspan=2, pady=(20, 20))

        close_account_button = Button(self.frame3, text="CLOSE\nACCOUNT", bg="#B22222", fg="#fff", cursor="hand2",  width=12, height=2, command = lambda : self._other.closeAccountHandler())
        close_account_button.configure(font=("Times New Roman", 25, "bold"))
        close_account_button.grid(row=20, column=3, padx=(30,), ipadx=3, columnspan=2, pady=(20, 20))

        logout_button = Button(self.frame3, text="LOGOUT", bg="#B22222", fg="#fff", width=12, height=2, cursor="hand2",  command = lambda : self._other.logOutHandler())
        logout_button.configure(font=("Times New Roman", 25, "bold"))
        logout_button.grid(row=20, column=20, padx=(25,), ipadx=3, columnspan=2, pady=(20, 20))

        self._root.mainloop()

    def updateProfile(self,user):

        self.clearGrid()
        self._root.minsize(900,710)
        self._root.title("    UPDATE PROFILE")
        self.setUpFrame(self._root)

        acc_num_label = Label(self.frame1, text="ACCOUNT NUMBER", bg="#bdb76b", fg="#000")
        acc_num_label.configure(font=("Times New Roman", 20, "bold"))
        acc_num_label.grid(row=0, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        acc_num_view_label = Label(self.frame1, text=user[0], bg="#bdb76b", fg="#000")
        acc_num_view_label.configure(font=("Times New Roman", 20, "bold"))
        acc_num_view_label.grid(row=0, column=20, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        name_label = Label(self.frame1, text="NAME", bg="#bdb76b", fg="#000")
        name_label.configure(font=("Times New Roman", 20, "bold"))
        name_label.grid(row=1, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        name_entry = Entry(self.frame1)
        name_entry.configure(font=("Times New Roman", 14))
        name_entry.insert(0,user[1])
        name_entry.grid(row=1, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))

        password_label = Label(self.frame1, text="PASSWORD", bg="#bdb76b", fg="#000")
        password_label.configure(font=("Times New Roman", 20, "bold"))
        password_label.grid(row=2, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        password_entry = Entry(self.frame1)
        password_entry.configure(font=("Times New Roman", 14))
        password_entry.insert(0, user[2])
        password_entry.grid(row=2, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))

        email_label = Label(self.frame1, text="EMAIL", bg="#bdb76b", fg="#000")
        email_label.configure(font=("Times New Roman", 20, "bold"))
        email_label.grid(row=3, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        email_entry = Entry(self.frame1)
        email_entry.configure(font=("Times New Roman", 14))
        email_entry.insert(0, user[3])
        email_entry.grid(row=3, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))

        mobile_number_label = Label(self.frame1, text="MOBILE NUMBER", bg="#bdb76b", fg="#000")
        mobile_number_label.configure(font=("Times New Roman", 20, "bold"))
        mobile_number_label.grid(row=4, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        mobile_number_entry = Entry(self.frame1)
        mobile_number_entry.configure(font=("Times New Roman", 14))
        mobile_number_entry.insert(0, user[4])
        mobile_number_entry.grid(row=4, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))

        aadhar_number_label = Label(self.frame1, text="AADHAR NUMBER", bg="#bdb76b", fg="#000")
        aadhar_number_label.configure(font=("Times New Roman", 20, "bold"))
        aadhar_number_label.grid(row=5, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        aadhar_number_entry = Entry(self.frame1)
        aadhar_number_entry.configure(font=("Times New Roman", 14))
        aadhar_number_entry.insert(0, user[5])
        aadhar_number_entry.grid(row=5, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))

        pan_number_label = Label(self.frame1, text="PAN NUMBER", bg="#bdb76b", fg="#000")
        pan_number_label.configure(font=("Times New Roman", 20, "bold"))
        pan_number_label.grid(row=6, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(20, 10))

        pan_number_entry = Entry(self.frame1)
        pan_number_entry.configure(font=("Times New Roman", 14))
        pan_number_entry.insert(0, user[6])
        pan_number_entry.grid(row=6, column=20, columnspan=5, sticky=W, ipadx=20, ipady=7, pady=(20, 10))

        self.viewImage(user[7])

        photo_label = Label(self.frame1, text="PHOTO", bg="#bdb76b", fg="#000")
        photo_label.configure(font=("Times New Roman", 20, "bold"))
        photo_label.grid(row=7, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10,))

        photo_button = Button(self.frame1, text="CHOOSE PHOTO", bg="#008000", fg="#fff", cursor="hand2", command=lambda: self.chooseImage(self._root))
        photo_button.configure(font=("Times New Roman", 14, "bold"))
        photo_button.grid(row=7, column=20, padx=(10, 10), ipadx=3, columnspan=2, pady=(10,))

        self._photo_path=user[7]

        ok_button = Button(self.frame1, text="OK", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self._other.updateProfileHandler([name_entry,password_entry,email_entry,mobile_number_entry,aadhar_number_entry,pan_number_entry,self._photo_path]))
        ok_button.configure(font=("Times New Roman", 15, "bold"))
        ok_button.grid(row=13, column=11, padx=(20,), ipadx=3, columnspan=2, pady=(30,))

        back_button = Button(self.frame3, text="BACK", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self.afterLogin())
        back_button.configure(font=("Times New Roman", 15, "bold"))
        back_button.grid(row=15, column=25, padx=(30,), ipadx=3, columnspan=2)

    def clearGrid(self):

        for i in self._root.grid_slaves() :
            i.destroy()

    def displayError(self,title,message):

        messagebox.showerror(title,message)

    def displayInfo(self,title,message):

        messagebox.showinfo(title,message)

    def displayYesNo(self,title,message):

        flag=messagebox.askyesno(title,message)
        return flag

    def firstPage(self):

        self.clearGrid()

        self._root.minsize(200, 300)
        self._root.title("    MY BANK")
        self.setUpFrame(self._root)
        self.viewUI(kind='First Page')
        self._root.mainloop()

    def createAccount(self):

        self.clearGrid()

        self._root.minsize(880,680)
        self._root.title("    CREATE ACCOUNT")
        self.setUpFrame(self._root)
        self.viewUI(kind="New Account")
        self._root.mainloop()

    def login(self):

        self.clearGrid()
        self._root.minsize(550,270)
        self._root.title("    LOGIN")
        self.setUpFrame(self._root)
        self.viewUI(kind="Login Page")
        self._root.mainloop()

    def chooseImage(self,root):

        self._path = filedialog.askopenfilename(
            parent=root,
            title='Choose Image',
            filetypes=[('jpg images (.jpg)', '.jpg'),
                       ('jpeg images (.jpeg)', '.jpeg'),
                       ('png images (.png)', '.png'),
                       ]
        )

        if self._path not in ['',tuple()] :
            self.viewImage(self._path)
            self._photo_path=self._path

    def viewImage(self, path):

        load = Image.open(path)
        load = load.resize((300, 300), Image.ANTIALIAS)
        render = ImageTk.PhotoImage(load)

        imageViewLabel = Label(self.frame2, image=render, bg="#bdb76b")
        imageViewLabel.image = render
        imageViewLabel.grid(row=7, column=25, columnspan=5, padx=(40, 0), pady=(20, 5))

    def closeWindow(self,root='root',logout=False):

        if self._root1 is not None:
            self._root1.destroy()
            self._root1=None

        if not logout and root != 'root1' :
            self._root.destroy()

    def transactionHistory(self,transaction_text):

        if self._root1 is None :

            self._root1=self.createRoot(secondRoot=True)
            self._root1.title("    TRANSACTION HISTORY")
            self._root1.minsize(800,620)
            self.setUpFrame(self._root1)

            transaction_list_label = Label(self.frame1, text=transaction_text, bg="#bdb76b", fg="#000", justify=LEFT)
            transaction_list_label.configure(font=("Times New Roman", 20, "bold"))
            transaction_list_label.grid(row=7, column=10, columnspan=5, sticky=W, padx=(10, 10), pady=(10, 5))

            refresh_button = Button(self.frame3, text="REFRESH", bg="#008000", fg="#fff", cursor="hand2", command = lambda : self._other.transactionHistoryHandler(refresh=True))
            refresh_button.configure(font=("Times New Roman", 15, "bold"))
            refresh_button.grid(row=12, column=3, padx=(20,), ipadx=3, columnspan=2, pady=(20, 20))

            self._root1.mainloop()

    def moneyTransfer(self):

        self.clearGrid()
        self._root.minsize(750,210)
        self.setUpFrame(self._root)
        self._root.title("    MONEY TRANSFER")
        self.viewUI(kind='transfer',receiver="RECEIVER'S ")